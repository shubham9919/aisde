COMMON_DDB = {
    'TABLE': 'visionbox_common',  # Table name in dynamoDB
    'KEY': 'COMMON',  # key
    'FEATURE': 'COMMON'  # feature
}
